from pathlib import Path
import re

HTML=Path('android/app/src/main/assets/web/admin.html')
GRADLE=Path('android/app/build.gradle')
VERSION=Path('VERSION.txt')
if not HTML.is_file() or not GRADLE.is_file(): raise SystemExit('Admin Android source root is missing.')
h=HTML.read_text(encoding='utf-8'); g=GRADLE.read_text(encoding='utf-8')
marker='V12.1.43-MONTHLY-REPORT-ACTIVE-EDIT'
if marker in h:
    if "versionCode 71" in g and "versionName '12.1.43'" in g: raise SystemExit(0)
    raise SystemExit('V12.1.43 marker/version mismatch.')
if 'V12.1.42-RENTAL-LEASE-EDIT-FIX' not in h or 'versionCode 70' not in g or "versionName '12.1.42'" not in g:
    raise SystemExit('Expected exact V12.1.42 baseline.')

def replace_once(old,new,label):
    global h
    if h.count(old)!=1: raise SystemExit(label+' anchor mismatch: '+str(h.count(old)))
    h=h.replace(old,new,1)

old_card='''<div class="card" id="dashboardReport30dCard" style="margin-top:12px">
 <div class="top"><div><b>Riwayat pemakaian 30 hari</b><div class="muted">Rekap sesi dimulai dan durasi aktif dari data rental tersimpan.</div></div><span id="dashboardReportPeriod" class="pill">Memuat periode…</span></div>
 <div class="table-wrap"><table class="table"><thead><tr><th>Tanggal</th><th>Sesi dimulai</th><th>Jam aktif</th></tr></thead><tbody id="dashboardReportRows"><tr><td colspan="3" class="empty">Memuat laporan 30 hari…</td></tr></tbody></table></div>
 <div id="dashboardReportMeta" class="muted" style="margin-top:8px">Mengambil data laporan dari database…</div>
</div>'''
new_card='''<div class="card" id="dashboardReport30dCard" style="margin-top:12px">
 <div class="top"><div><b>Laporan pemakaian bulan ini</b><div class="muted">Rekap otomatis dari tanggal 1 sampai akhir bulan berdasarkan ID rental.</div></div><span id="dashboardReportPeriod" class="pill">Memuat periode…</span></div>
 <div class="table-wrap" id="dashboardMonthlyReportWrap"><table class="table" id="dashboardMonthlyReportTable">
  <thead><tr><th>ID Rental</th><th>Nama</th><th>Total Bermain</th><th>Total Sesi</th></tr></thead>
  <tbody id="dashboardReportRows"><tr><td colspan="4" class="empty">Memuat laporan bulanan…</td></tr></tbody>
  <tfoot><tr><td colspan="2"><b>TOTAL</b></td><td id="dashboardReportTotalPlay"><b>-</b></td><td id="dashboardReportTotalSessions"><b>0</b></td></tr></tfoot>
 </table></div><div id="dashboardReportMeta" class="muted" style="margin-top:8px">Mengambil rekap bulanan dari database…</div>
</div>'''
replace_once(old_card,new_card,'Dashboard monthly table')

anchor="function jakartaDateString(date=new Date()){return new Date(date.getTime()+7*3600000).toISOString().slice(0,10)}function dates(){"
helper="""function setAdminDefaultMonthRange(){
 const t=jakartaDateString(new Date()),p=t.split('-').map(Number),days=new Date(Date.UTC(p[0],p[1],0)).getUTCDate();
 $('from').value=p[0]+'-'+String(p[1]).padStart(2,'0')+'-01';
 $('to').value=p[0]+'-'+String(p[1]).padStart(2,'0')+'-'+String(days).padStart(2,'0');
}
"""
replace_once(anchor,helper+anchor,'Month date helper')
replace_once("updateDbSyncDirection();updateDbSyncModeNote();$('from').value=jakartaDateString(new Date(Date.now()-29*864e5));$('to').value=jakartaDateString();$('reportDetailDate').value=jakartaDateString();",
             "updateDbSyncDirection();updateDbSyncModeNote();setAdminDefaultMonthRange();$('reportDetailDate').value=jakartaDateString();",'Month default range')

start=h.find('let dashboardReportRequestSeq = 0;'); end=h.find('async function loadReport(){',start)
if start<0 or end<0: raise SystemExit('Dashboard report JS boundary mismatch.')
js=r'''let dashboardReportRequestSeq = 0;
function dashboardReportFormatTime(v){const s=Math.max(0,Math.floor(Number(v)||0)),h=Math.floor(s/3600),m=Math.floor((s%3600)/60);return h?h+'j '+String(m).padStart(2,'0')+'m':m?m+'m':s+'d'}
function drawDashboardReportMonthly(daily,rentals){
 const trend=$('trendChart'),mix=$('categoryChart');if(!window.Chart||!trend||!mix)return;
 destroy('dashboard30Trend');destroy('dashboard30Mix');
 const labels=daily.map(x=>String(x.date||'').slice(8,10)),values=daily.map(x=>Number(x.active_seconds||0)/3600);
 charts.dashboard30Trend=new Chart(trend,{type:'line',data:{labels,datasets:[{label:'Jam aktif bulan ini',data:values,tension:.25,fill:true}]},options:{responsive:true,maintainAspectRatio:false,layout:{padding:{left:4,right:4,top:2,bottom:2}},plugins:{legend:{display:true,position:'top',labels:{boxWidth:12,padding:8,font:{size:10}}}},scales:{x:{ticks:{autoSkip:true,maxTicksLimit:10,maxRotation:0}},y:{beginAtZero:true}}}});
 const top=rentals.filter(x=>Number(x.total_play_seconds||0)>0).slice(0,5),shortId=v=>{const s=String(v||'-');return s.length>12?s.slice(0,11)+'…':s};
 charts.dashboard30Mix=new Chart(mix,{type:'doughnut',data:{labels:top.length?top.map(x=>shortId(x.rental_id)):['Belum ada data'],datasets:[{label:'Jam bermain',data:top.length?top.map(x=>Number(x.total_play_seconds||0)/3600):[0]}]},options:{responsive:true,maintainAspectRatio:false,cutout:'58%',layout:{padding:{left:6,right:6,top:2,bottom:2}},plugins:{legend:{display:true,position:'bottom',align:'center',labels:{usePointStyle:true,pointStyle:'rect',boxWidth:10,boxHeight:8,padding:6,font:{size:9}}}}}});
}
async function loadDashboardReport30d(){
 const orgId=currentOrg?.id;if(!orgId)return;const req=++dashboardReportRequestSeq,today=jakartaDateString(new Date()),p=today.split('-').map(Number),year=p[0],month=p[1];
 const first=year+'-'+String(month).padStart(2,'0')+'-01',days=new Date(Date.UTC(year,month,0)).getUTCDate(),startMs=new Date(first+'T00:00:00+07:00').getTime(),endMs=startMs+days*864e5;
 const body=$('dashboardReportRows'),period=$('dashboardReportPeriod'),meta=$('dashboardReportMeta'),totalPlay=$('dashboardReportTotalPlay'),totalSessions=$('dashboardReportTotalSessions');
 const monthName=new Intl.DateTimeFormat('id-ID',{month:'long',timeZone:'Asia/Jakarta'}).format(new Date(startMs));
 if(period)period.textContent='01–'+String(days).padStart(2,'0')+' '+monthName+' '+year;
 if(body)body.innerHTML='<tr><td colspan="4" class="empty">Memuat laporan bulanan…</td></tr>';if(meta)meta.textContent='Mengambil ringkasan sesi rental bulan ini…';if(totalPlay)totalPlay.textContent='-';if(totalSessions)totalSessions.textContent='0';
 destroy('dashboard30Trend');destroy('dashboard30Mix');
 try{
  const data=await rpc('report_monthly_rental_summary',{p_org_id:orgId,p_from:new Date(startMs).toISOString(),p_to:new Date(endMs).toISOString()});
  if(req!==dashboardReportRequestSeq||currentOrg?.id!==orgId)return;
  if(!Array.isArray(data?.rows)||!Array.isArray(data?.daily))throw new Error('Format rekap bulanan dari database tidak valid.');
  const rentals=data.rows,daily=data.daily,totalSec=Number(data.total_play_seconds)||0,totalCount=Number(data.total_sessions)||0;
  if(body)body.innerHTML=rentals.length?rentals.map(x=>'<tr><td><b>'+esc(x.rental_id||'-')+'</b></td><td>'+esc(x.rental_name||'-')+'</td><td><b>'+esc(dashboardReportFormatTime(x.total_play_seconds))+'</b></td><td>'+Number(x.total_sessions||0).toLocaleString('id-ID')+'</td></tr>').join(''):'<tr><td colspan="4" class="empty">Belum ada sesi rental pada bulan ini.</td></tr>';
  if(totalPlay)totalPlay.textContent=dashboardReportFormatTime(totalSec);if(totalSessions)totalSessions.textContent=totalCount.toLocaleString('id-ID');
  if(meta)meta.textContent=Number(data.rental_count||rentals.length).toLocaleString('id-ID')+' rental • '+totalCount.toLocaleString('id-ID')+' sesi • '+dashboardReportFormatTime(totalSec)+' total bermain';
  drawDashboardReportMonthly(daily,rentals);
 }catch(e){if(req!==dashboardReportRequestSeq||currentOrg?.id!==orgId)return;if(body)body.innerHTML='<tr><td colspan="4" class="empty">Laporan bulanan gagal dimuat.</td></tr>';if(meta)meta.textContent=String(e?.message||'Gagal memuat rekap bulanan.')}
}

'''
h=h[:start]+js+h[end:]

# Replace only the edit handler; the backend keeps unsafe active-session mutations locked.
start=h.find('async function saveAdminRentalEdit(){'); end=h.find("\ndocument.addEventListener('click'",start)
if start<0 or end<0: raise SystemExit('Rental edit JS boundary mismatch.')
edit=r'''async function saveAdminRentalEdit(){
 if(!adminRentalEditState)return;const st=adminRentalEditState;
 try{
  if(!currentOrg)throw new Error('Organisasi belum dipilih.');
  const code=$('adminEditRentalCode').value.trim().toUpperCase();if(!code)throw new Error('Kode rental wajib diisi.');if(code.length>120)throw new Error('Kode rental maksimal 120 karakter.');
  const nextMinutes=Number($('adminEditRentalMinutes').value);if(!Number.isSafeInteger(nextMinutes)||nextMinutes<0||nextMinutes>525600)throw new Error('Sisa menit harus 0 sampai 525600.');
  const expiryInput=$('adminEditRentalExpiry').value,originalExpiry=st.original?.expiry_at||null;
  const expiry=expiryInput===adminToLocalInput(originalExpiry)?originalExpiry:adminLocalToISO(expiryInput);
  if(expiry&&new Date(expiry).getTime()<=Date.now()&&expiry!==originalExpiry)throw new Error('Tanggal expiry harus di masa depan.');
  const r=await rpc('admin_update_rental_global',{p_org_id:currentOrg.id,p_rental_id:st.id,p_code:code,p_category:$('adminEditRentalCategory').value,p_minutes:Math.round(nextMinutes),p_client_label:$('adminEditRentalClient').value.trim()||null,p_expiry_at:expiry,p_status:$('adminEditRentalStatus').value});
  if(r?.ok!==true)throw new Error('Database tidak mengonfirmasi perubahan rental.');closeAdminRentalEdit();
  const note=r.time_command_queued===true?' Perintah penambahan '+Math.round(Number(r.seconds_added||0)/60)+' menit sudah masuk antrean PC; timer bertambah setelah diproses.':'';
  msg('Rental '+code+' berhasil diperbarui di database bersama.'+note+rentalAdminLeaseNote(r));await loadGlobalRentalAccounts();
 }catch(e){msg('Gagal edit '+st.code+': '+rentalAdminFriendlyError(e),true)}
}
'''
h=h[:start]+edit+h[end:]

replace_once('<div class="muted">Perubahan langsung disimpan ke database bersama dan tidak menunggu PC online. Jika ada lease/reservasi lama, reservasi itu tetap dijaga sampai kedaluwarsa agar kode tidak dipakai ganda. PC pemegang lease mengambil data terbaru saat koneksi/lookup berikutnya.</div>',
 '''<div class="muted">Saat rental sedang aktif/paused, nama dan kategori tetap bisa diedit. Menambah sisa waktu dikirim ke timer PC pemegang sesi (PC harus online). Mengurangi waktu, mengganti kode, mengubah expiry/status, atau menonaktifkan rental menunggu sesi selesai. Lease lama tetap dijaga agar kode tidak dipakai ganda.</div>''','Active session modal note')
friendly=" if(code.includes('RENTAL_ACTIVE_TIMER_LOCKED'))return 'Rental sedang dipakai dalam sesi aktif/paused. Akhiri sesi dari PC yang sedang memakai rental sebelum mengubah kode, durasi, expiry, atau status.';"
friendly_new=""" if(code.includes('RENTAL_ACTIVE_TIME_REDUCTION_BLOCKED'))return 'Rental sedang berjalan. Sisa waktu hanya bisa ditambah saat sesi aktif; pengurangan waktu dilakukan setelah sesi selesai.';
 if(code.includes('RENTAL_ACTIVE_DEVICE_OFFLINE'))return 'PC pemegang sesi tidak terhubung/heartbeat sudah lama. Data lain tetap aman; tambah waktu aktif perlu menunggu PC online.';
 if(code.includes('RENTAL_PAUSED_TIME_EDIT_UNSUPPORTED'))return 'Sesi sedang dijeda. Nama/kategori masih bisa diedit, tetapi tambahkan waktu setelah sesi dilanjutkan agar timer tersinkron aman.';
 if(code.includes('RENTAL_ACTIVE_DEVICE_UNAVAILABLE'))return 'PC pemegang sesi tidak ditemukan. Periksa pairing sebelum mengubah timer.';
 if(code.includes('RENTAL_ACTIVE_SESSION_STATE_UNAVAILABLE'))return 'Status timer terakhir belum tersinkron. Pastikan PC online dan tunggu heartbeat sebelum menambah waktu.';
 if(code.includes('RENTAL_ACTIVE_CODE_LOCKED'))return 'Kode rental tidak dapat diganti saat sesi aktif/paused. Ubah kode setelah sesi selesai.';
 if(code.includes('RENTAL_ACTIVE_EXPIRY_LOCKED'))return 'Tanggal expired tidak dapat diubah saat sesi aktif/paused. Ubah setelah sesi selesai.';
 if(code.includes('RENTAL_ACTIVE_STATUS_LOCKED'))return 'Status tidak dapat dinonaktifkan saat sesi aktif/paused. Selesaikan sesi terlebih dahulu.';
 if(code.includes('RENTAL_ACTIVE_TIMER_LOCKED'))return 'Rental sedang dipakai dalam sesi aktif/paused. Perubahan timer yang tidak aman ditolak.';"""
replace_once(friendly,friendly_new,'Active session friendly errors')

css=r'''
/* V12.1.43 Android dashboard width/legend/table fixes. */
#overview .cards2,#overview .cards2>.card{min-width:0;max-width:100%}
#overview .cards2>#dashboardReport30dCard,#overview .cards2>.activity-card{grid-column:1/-1}
#overview .chartbox{width:100%;min-width:0;max-width:100%;overflow:hidden}
#overview .chartbox canvas{display:block!important;width:100%!important;max-width:100%!important}
#dashboardReport30dCard{width:100%;min-width:0;max-width:100%;overflow:hidden}
#dashboardReport30dCard .table-wrap{display:block;width:100%;min-width:0;max-width:100%;overflow-x:auto;overflow-y:hidden;overscroll-behavior-x:contain;-webkit-overflow-scrolling:touch}
#dashboardReport30dCard table{width:100%;min-width:0;max-width:100%;table-layout:fixed}
#dashboardReport30dCard th,#dashboardReport30dCard td{padding:8px 6px;white-space:normal;overflow-wrap:anywhere;word-break:break-word}
#dashboardReport30dCard th:nth-child(1),#dashboardReport30dCard td:nth-child(1){width:23%}
#dashboardReport30dCard th:nth-child(2),#dashboardReport30dCard td:nth-child(2){width:25%}
#dashboardReport30dCard th:nth-child(3),#dashboardReport30dCard td:nth-child(3){width:32%}
#dashboardReport30dCard th:nth-child(4),#dashboardReport30dCard td:nth-child(4){width:20%;text-align:right}
@media(max-width:700px){
 #overview .cards2{grid-template-columns:minmax(0,1fr)!important}
 #overview .cards2>.card{grid-column:1/-1;min-width:0;width:100%;max-width:100%}
 #overview .chartbox{height:240px!important}
 #dashboardReport30dCard .table{font-size:11px}
 #dashboardReport30dCard th,#dashboardReport30dCard td{padding:8px 4px}
 #dashboardReport30dCard .top{align-items:flex-start;flex-wrap:wrap}
 body{padding-bottom:calc(116px + env(safe-area-inset-bottom))!important}
 #app.wrap{padding-bottom:calc(132px + env(safe-area-inset-bottom))!important}
}
'''
if h.count('</style>')!=1: raise SystemExit('Admin style close anchor mismatch.')
h=h.replace('</style>',css+'\n</style>',1)

base='V12.1.42-RENTAL-LEASE-EDIT-FIX'
if h.count(base)!=1: raise SystemExit('V12.1.42 marker mismatch.')
h=h.replace(base,base+' • '+marker,1)
g,n1=re.subn(r'\bversionCode\s+70\b','versionCode 71',g,count=1)
g,n2=re.subn(r"versionName\s*'12\.1\.42'","versionName '12.1.43'",g,count=1)
if n1!=1 or n2!=1: raise SystemExit('Gradle version anchor mismatch.')
required=(marker,'report_monthly_rental_summary','ID Rental','Total Bermain','Total Sesi','time_command_queued',
 'RENTAL_ACTIVE_TIME_REDUCTION_BLOCKED','RENTAL_ACTIVE_DEVICE_OFFLINE','setAdminDefaultMonthRange','dashboardReportFormatTime',
 'grid-column:1/-1','V12.1.40-ADMIN-NO-SHUTDOWN','V12.1.41-DASHBOARD-30D-REPORT',base,'wake_on_lan_relay',
 'admin_rental_accounts_global','admin_create_rental_global','admin_update_rental_global','admin_disable_rental_global',
 'requestSharedDbRouteSwitch','admin_get_free_test_policy')
for token in required:
 if token not in h: raise SystemExit('Missing required feature marker: '+token)
for token in ('pcShutdownTimerCard','shutdownTimerNav','shutdownHours','shutdownMinutes','shutdownSeconds','schedulePcShutdown','cancelPcShutdown','schedule_shutdown','cancel_shutdown_timer'):
 if token in h: raise SystemExit('Removed shutdown timer reappeared: '+token)
ids=re.findall(r'\bid=["\']([^"\']+)',h);dups=sorted({x for x in ids if ids.count(x)>1})
if dups: raise SystemExit('Duplicate HTML IDs: '+', '.join(dups))
HTML.write_text(h,encoding='utf-8');GRADLE.write_text(g,encoding='utf-8')
VERSION.write_text('AniGames Admin Android V12.1.43 — month-scoped rental report (day 1 to calendar month end), responsive dashboard charts/table, and guarded active-session time additions via existing PC add_time command.\n',encoding='utf-8')
print('PASS: monthly report ID/name/play time/session totals; full calendar-month defaults; mobile width and bottom-nav layout.')
print('PASS: active session time additions enter PC command queue; reductions/code/expiry/status changes remain guarded.')
print('PASS: V12.1.43 / versionCode 71; previous Admin features and no-shutdown state retained.')
