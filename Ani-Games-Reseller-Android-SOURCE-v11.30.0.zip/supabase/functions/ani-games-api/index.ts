const corsHeaders = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET,POST,OPTIONS",
  "access-control-allow-headers": "authorization,content-type,apikey,x-client-info",
  "content-type": "application/json; charset=utf-8",
};
const json = (status: number, body: unknown) => new Response(JSON.stringify(body), { status, headers: corsHeaders });
const base = () => (Deno.env.get("SUPABASE_URL") || "").replace(/\/$/, "");
const apiKey = () => Deno.env.get("SUPABASE_ANON_KEY") || Deno.env.get("SUPABASE_PUBLISHABLE_KEY") || "";
const publishableKey = () => {
  const raw = Deno.env.get("SUPABASE_PUBLISHABLE_KEYS") || "";
  try { const parsed = JSON.parse(raw); if (parsed.default) return parsed.default; } catch (_) {}
  return Deno.env.get("SUPABASE_PUBLISHABLE_KEY") || apiKey();
};
async function rpc(name: string, body: Record<string, unknown>, userToken?: string) {
  const u = base(), k = apiKey();
  if (!u || !k) throw new Error("SUPABASE_API_NOT_CONFIGURED");
  const headers: Record<string, string> = {
    apikey: k,
    "content-type": "application/json",
    "Content-Profile": "api",
    "Accept-Profile": "api",
  };
  // Never send a new sb_publishable_* key as a Bearer token. Only a real user JWT is forwarded.
  if (userToken) headers.authorization = `Bearer ${userToken}`;
  else if (/^eyJ[A-Za-z0-9_-]+\./.test(k)) headers.authorization = `Bearer ${k}`;
  const response = await fetch(`${u}/rest/v1/rpc/${name}`, { method: "POST", headers, body: JSON.stringify(body) });
  const text = await response.text();
  let data: any;
  try { data = JSON.parse(text); } catch { data = { message: text }; }
  if (!response.ok) throw new Error(data?.message || data?.hint || `Supabase RPC ${response.status}`);
  return data;
}
async function authUser(token: string) {
  if (!token || !base() || !apiKey()) return null;
  const response = await fetch(`${base()}/auth/v1/user`, { headers: { apikey: apiKey(), authorization: `Bearer ${token}` } });
  return response.ok ? await response.json() : null;
}
const bearer = (request: Request) => {
  const value = request.headers.get("authorization") || "";
  return value.startsWith("Bearer ") ? value.slice(7).trim() : "";
};
function normalize(value: string) {
  let path = String(value || "").split("?")[0].replace(/\\/g, "/").replace(/^\/+/, "").replace(/\/+$/, "");
  path = path.replace(/^functions\/v1\/ani-games-api\/?/, "").replace(/^ani-games-api\/?/, "");
  path = path.replace(/^api\/v1\/?/, "");
  return path;
}
async function requireOwner(token: string) {
  const user = await authUser(token);
  if (!user) throw new Error("invalid_or_expired_token");
  const context = await rpc("admin_context", {}, token);
  if (context?.role !== "owner") throw new Error("owner_only");
  return user;
}
function blynkToken() { return Deno.env.get("BLYNK_AUTH_TOKEN") || ""; }
async function blynkStatus(token: string) {
  const url = new URL("https://blynk.cloud/external/api/isHardwareConnected");
  url.searchParams.set("token", token);
  const response = await fetch(url.toString());
  const body = (await response.text()).trim();
  if (!response.ok) return { ok: false, status: 502, error: "blynk_status_unavailable", detail: body || `HTTP ${response.status}` };
  if (/invalid token|error/i.test(body)) return { ok: false, status: 502, error: "blynk_status_rejected", detail: body };
  return { ok: true, online: body.toLowerCase() === "true" };
}
async function handler(request: Request) {
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: corsHeaders });
  const url = new URL(request.url);
  const candidates = [url.pathname, request.headers.get("x-original-url") || ""];
  let path = "";
  for (const candidate of candidates) {
    const normalized = normalize(candidate);
    if (normalized) { path = normalized; break; }
  }
  try {
    if (request.method === "GET" && path === "health") {
      const configured = Boolean(base() && apiKey());
      return json(configured ? 200 : 503, { ok: configured, service: "ani-games-billing-supabase", apiVersion: "v1", supabaseConfigured: configured, time: new Date().toISOString() });
    }
    if (request.method === "GET" && path === "auth/me") {
      const token = bearer(request);
      if (!token) return json(401, { ok: false, error: "missing_bearer_token" });
      const user = await authUser(token);
      if (!user) return json(401, { ok: false, error: "invalid_or_expired_token" });
      return json(200, { ok: true, user: { id: user.id, email: user.email } });
    }
    if (path === "iot/status") {
      if (request.method !== "GET") return json(405, { ok: false, error: "method_not_allowed" });
      const token = bearer(request);
      if (!token) return json(401, { ok: false, error: "missing_bearer_token" });
      await requireOwner(token);
      const secret = blynkToken();
      if (!secret) return json(503, { ok: false, error: "BLYNK_AUTH_TOKEN_NOT_CONFIGURED_IN_SUPABASE" });
      const status = await blynkStatus(secret);
      if (!status.ok) return json(status.status, status);
      return json(200, status);
    }
    if (path === "iot/power") {
      if (request.method !== "POST") return json(405, { ok: false, error: "method_not_allowed" });
      const token = bearer(request);
      if (!token) return json(401, { ok: false, error: "missing_bearer_token" });
      await requireOwner(token);
      const body = await request.json().catch(() => ({}));
      if (!body?.deviceId) return json(400, { ok: false, error: "device_id_required" });
      const secret = blynkToken();
      if (!secret) return json(503, { ok: false, error: "BLYNK_AUTH_TOKEN_NOT_CONFIGURED_IN_SUPABASE" });
      const status = await blynkStatus(secret);
      if (!status.ok) return json(status.status, status);
      if (!status.online) return json(503, { ok: false, error: "blynk_device_offline" });
      for (const value of ["1", "0"]) {
        const pulse = new URL("https://blynk.cloud/external/api/update");
        pulse.searchParams.set("token", secret); pulse.searchParams.set("V0", value);
        const response = await fetch(pulse.toString());
        const bodyText = (await response.text()).trim();
        if (!response.ok || /error|invalid token|wrong pin|no datastream/i.test(bodyText)) {
          return json(502, { ok: false, error: value === "1" ? "blynk_command_failed" : "blynk_release_failed", detail: bodyText || `HTTP ${response.status}` });
        }
        if (value === "1") await new Promise(resolve => setTimeout(resolve, 500));
      }
      return json(200, { ok: true, message: "power_pulse_sent", pin: "V0" });
    }
    if (request.method !== "POST") return json(404, { ok: false, error: "not_found" });
    const body: any = await request.json().catch(() => ({}));
    if (path === "device/enroll") {
      return json(200, { ok: true, ...await rpc("redeem_device", { p_code: String(body.code || ""), p_client_id: String(body.clientId || ""), p_device_name: String(body.deviceName || ""), p_app_version: String(body.appVersion || "") }) });
    }
    if (path === "device/heartbeat") {
      return json(200, { ok: true, ...await rpc("device_heartbeat", { p_token: String(body.token || ""), p_app_version: String(body.appVersion || ""), p_metadata: body.metadata || {} }) });
    }
    if (path === "device/ack") {
      const token = String(body.token || ""), commandId = String(body.commandId || ""), status = String(body.status || "acknowledged"), result = body.result || {};
      const ack = await rpc("device_ack", { p_token: token, p_command_id: commandId, p_status: status, p_result: result });
      const trial = await rpc("device_finalize_trial", { p_token: token, p_command_id: commandId, p_status: status, p_result: result });
      return json(200, { ok: true, ...ack, trial });
    }
    if (path === "device/sync") {
      const result = await rpc("device_sync", { p_token: String(body.token || ""), p_events: Array.isArray(body.events) ? body.events : [] });
      return json(200, { ok: true, ...result });
    }
    if (path === "device/pull") {
      const result = await rpc("device_pull_sync", { p_token: String(body.token || ""), p_cursor: body.cursor ? String(body.cursor) : null });
      return json(200, { ok: true, ...result });
    }
    if (path === "device/rentals") {
      const result = await rpc("device_rentals_snapshot", { p_token: String(body.token || "") });
      return json(200, result);
    }
    return json(404, { ok: false, error: "not_found", path });
  } catch (error) {
    const message = error instanceof Error ? error.message : "request_failed";
    const status = /INVALID_DEVICE_TOKEN|INVALID_ENROLLMENT|invalid_or_expired_token|AUTH_REQUIRED/.test(message) ? 401 : /owner_only|ADMIN_ROLE_REQUIRED/.test(message) ? 403 : 400;
    return json(status, { ok: false, error: message });
  }
}
Deno.serve(handler);

