-- v11.29.0: backfill historical rental rows with no device_id to the primary device per org.
-- Primary = device with most already-linked rental accounts (stable tie-breaks follow heartbeat and created_at).
-- Preserves all rental timer fields. Writes a metadata marker so this can be audited or rolled back.
WITH ranked_devices AS MATERIALIZED (
  SELECT d.id AS device_id, d.org_id, d.created_at,
         row_number() OVER (PARTITION BY d.org_id ORDER BY count(r.id) DESC,
           max(coalesce(d.last_heartbeat_at,d.last_seen_at)) DESC NULLS LAST, d.created_at ASC) AS rn
  FROM public.devices d LEFT JOIN public.rental_accounts r ON r.device_id=d.id
  GROUP BY d.id,d.org_id,d.created_at
), primary_devices AS MATERIALIZED (
  SELECT device_id,org_id FROM ranked_devices WHERE rn=1
), targets AS MATERIALIZED (
  SELECT r.id,r.org_id,r.code,p.device_id FROM public.rental_accounts r
  JOIN primary_devices p ON p.org_id=r.org_id WHERE r.device_id IS NULL
), rental_backfill AS (
  UPDATE public.rental_accounts r SET device_id=t.device_id, updated_at=now(),
    metadata=coalesce(r.metadata,'{}'::jsonb) || jsonb_build_object('_migration_v11_29_device_backfill',
      jsonb_build_object('device_id',t.device_id,'at',now(),'previous_device_id',null))
  FROM targets t WHERE r.id=t.id AND r.device_id IS NULL RETURNING r.id
), session_backfill AS (
  UPDATE public.rental_sessions s SET device_id=t.device_id, rental_account_id=coalesce(s.rental_account_id,t.id),
    metadata=coalesce(s.metadata,'{}'::jsonb) || jsonb_build_object('_migration_v11_29_device_backfill',
      jsonb_build_object('device_id',t.device_id,'at',now(),'previous_device_id',null))
  FROM targets t WHERE s.org_id=t.org_id AND upper(s.code)=upper(t.code) AND s.device_id IS NULL RETURNING s.id
), transaction_backfill AS (
  UPDATE public.billing_transactions b SET device_id=t.device_id,
    metadata=coalesce(b.metadata,'{}'::jsonb) || jsonb_build_object('_migration_v11_29_device_backfill',
      jsonb_build_object('device_id',t.device_id,'at',now(),'previous_device_id',null))
  FROM targets t WHERE b.org_id=t.org_id AND b.rental_account_id=t.id AND b.device_id IS NULL RETURNING b.id
), event_backfill AS (
  UPDATE public.usage_events e SET device_id=t.device_id,
    payload=coalesce(e.payload,'{}'::jsonb) || jsonb_build_object('_migration_v11_29_device_backfill',
      jsonb_build_object('device_id',t.device_id,'at',now(),'previous_device_id',null))
  FROM targets t WHERE e.org_id=t.org_id AND e.rental_account_id=t.id AND e.device_id IS NULL RETURNING e.id
)
SELECT (SELECT count(*) FROM rental_backfill) AS rentals_updated,
       (SELECT count(*) FROM session_backfill) AS sessions_updated,
       (SELECT count(*) FROM transaction_backfill) AS transactions_updated,
       (SELECT count(*) FROM event_backfill) AS usage_events_updated;

-- The production backfill was already executed and verified on 2026-10-10.
-- Optional rollback: only run intentionally, after a fresh backup/review. Rows created or edited after migration may have preserved this marker.
-- UPDATE public.rental_accounts SET device_id=NULL, metadata=metadata-'_migration_v11_29_device_backfill'
-- WHERE metadata->'_migration_v11_29_device_backfill'->>'device_id'=device_id::text;
-- UPDATE public.rental_sessions SET device_id=NULL, metadata=metadata-'_migration_v11_29_device_backfill'
-- WHERE metadata->'_migration_v11_29_device_backfill'->>'device_id'=device_id::text;
-- UPDATE public.billing_transactions SET device_id=NULL, metadata=metadata-'_migration_v11_29_device_backfill'
-- WHERE metadata->'_migration_v11_29_device_backfill'->>'device_id'=device_id::text;
-- UPDATE public.usage_events SET device_id=NULL, payload=payload-'_migration_v11_29_device_backfill'
-- WHERE payload->'_migration_v11_29_device_backfill'->>'device_id'=device_id::text;
