# Audit varian Ani Games Reseller v11.30.0

## Hasil audit source
- Basis: Android source v11.29.1 APIKEY-FIX; Supabase project URL dan publishable key dipertahankan.
- Login tetap melalui `billing_login` dan `billing_context`.
- UI diubah untuk menyisakan pemilihan PC, status PC, daftar rental, tambah rental, edit rental, dan hapus rental.
- Link Dashboard Admin, tombol putus pairing, kontrol Billing/Windows, trial, dan daftar kontrol sesi dihapus dari antarmuka reseller.
- Logo login dan launcher icon bawaan dipertahankan.
- Android versionCode dinaikkan menjadi 31; versionName `11.30.0-reseller`.

## Pengujian yang dilakukan
- Pemeriksaan statis markup/handler dan konsistensi file workflow.
- Tidak ada Android SDK/Gradle terpasang pada lingkungan audit ini, sehingga APK belum dapat dikompilasi secara lokal.
- Login langsung ke Supabase, role authorization server-side, CRUD rental, serta uji ponsel belum dapat dinyatakan lulus hanya dari source ZIP.

## Pengamanan sebelum rilis
Menyembunyikan tombol bukan kontrol keamanan. Supabase harus memvalidasi role pada setiap RPC. Pastikan reseller hanya boleh membaca dan mengubah rental untuk PC yang memang diizinkan pada organisasinya, dan ditolak untuk RPC admin, pairing, Windows, trial, dan session command. Jangan menganggap build sukses sebagai bukti otorisasi aman.
