# Ani Games Reseller Android — PRE-BUILD v11.30.0

Ini adalah source project Android untuk APK WebView (belum dikompilasi menjadi `.apk`). UI master Web/Admin v11.28.11 dipertahankan dan asset di `app/src/main/assets/web/` sudah diselaraskan ke v11.29.1 untuk jalur Supabase langsung.

## Build APK
**Lewat GitHub Actions (disarankan):** ikuti `GITHUB-BUILD-APK.md`. Ekstrak seluruh isi ZIP ke root repository (termasuk folder `.github`), push ke branch `main`/`master`, atau jalankan workflow `Build Android APK` secara manual. Unduh artifact `Ani-Games-Reseller-Android-v11.30.0-debug-apk` setelah workflow berhasil.

**Lewat Android Studio:** ekstrak ZIP, buka folder `android/` sebagai project, pasang Android SDK 35 dan JDK 17, lalu pilih **Build → Build APK(s)**. Untuk distribusi release, pilih **Build → Generate Signed Bundle / APK** dan gunakan keystore milik sendiri. APK debug output: `android/app/build/outputs/apk/debug/app-debug.apk`.

## Catatan fungsi dan koneksi
- Login, Admin Dashboard, Billing Control, rental, laporan, dan pairing menggunakan Supabase direct.
- Endpoint perangkat menggunakan Supabase Edge Function `ani-games-api`.
- Publishable API key pada asset merupakan public key; jangan pernah menambahkan `service_role`, secret key, atau token Blynk ke asset APK.
- Supabase Auth, database RPC, dan data cloud memerlukan internet; fungsi timer offline yang hanya dimiliki Billing PC tidak ikut dijalankan oleh aplikasi admin Android.
- Kontrol IoT memerlukan secret `BLYNK_AUTH_TOKEN` di Supabase Edge Functions Secrets sebelum dapat berfungsi.
- Tidak ada Gradle Wrapper atau release keystore dalam source ini. Gunakan Android Studio untuk membuat wrapper/build konfigurasi lokal dan menandatangani rilis.

Audit statis dilakukan, tetapi login, semua RPC, dan interaksi pada ponsel fisik tetap wajib dites setelah APK dibangun.


## Varian reseller v11.30.0 — batas fitur
- UI hanya menampilkan pemilihan PC dan tambah/edit/hapus data rental member.
- Tombol Dashboard Admin, putus pairing, kontrol Windows/Billing, trial, serta kontrol sesi tidak ditampilkan pada varian ini.
- Ini adalah pembatasan UI; otorisasi keamanan tetap wajib ditegakkan di Supabase RPC/RLS. Sebelum distribusi, verifikasi bahwa role reseller ditolak untuk `admin_disconnect_device`, `billing_command`, `billing_start_trial`, dan seluruh fungsi admin dashboard.
- APK debug v11.29.1 yang sebelumnya tersedia bukan APK reseller final.
