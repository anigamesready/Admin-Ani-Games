# API key fix v11.29.1

Root cause confirmed from Supabase project logs on 2026-10-10: the v11.29.0 APK sent `sb_publishable_1Jsp...`; Supabase Gateway rejected the `billing_login` RPC request before login validation with HTTP 401 `UNAUTHORIZED_INVALID_API_KEY` / `bad_length`. The key used by the locked Web master (`sb_publishable_Dobd...`) has successful 200 responses in the same project logs.

This patch changes all Android web assets to the already-used master key, keeps the same Supabase project URL, and bumps Android versionCode/versionName to 30 / 11.29.1. No username, password, database rows, or UI layout is changed.

After replacing the repository source ZIP, build again in GitHub Actions and install the newly created artifact. Do not keep both old and fixed source ZIPs at repository root because the repository workflow selects the first `*GITHUB-BUILD*.zip` it finds.
