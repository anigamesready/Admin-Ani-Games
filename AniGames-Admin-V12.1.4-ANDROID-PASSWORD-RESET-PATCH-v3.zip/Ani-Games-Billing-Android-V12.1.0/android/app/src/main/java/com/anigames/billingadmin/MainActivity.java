package com.anigames.billingadmin;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    private String pendingRecoveryUri;
    private boolean pageLoaded = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(true);

        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pageLoaded = true;
                dispatchPendingRecovery();
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        handleRecoveryIntent(getIntent());
        web.loadUrl("file:///android_asset/web/admin.html");
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleRecoveryIntent(intent);
    }

    private void handleRecoveryIntent(Intent intent) {
        if (intent == null || intent.getData() == null || web == null) return;
        String uri = intent.getData().toString();
        if (!uri.startsWith("anigamesadmin://recovery")) return;
        pendingRecoveryUri = uri;
        dispatchPendingRecovery();
    }

    private void dispatchPendingRecovery() {
        if (web == null || pendingRecoveryUri == null || !pageLoaded) return;
        final String safeUri = JSONObject.quote(pendingRecoveryUri);
        pendingRecoveryUri = null;
        web.post(() -> web.evaluateJavascript("if(window.handleRecoveryLink){window.handleRecoveryLink(" + safeUri + ");}", null));
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
