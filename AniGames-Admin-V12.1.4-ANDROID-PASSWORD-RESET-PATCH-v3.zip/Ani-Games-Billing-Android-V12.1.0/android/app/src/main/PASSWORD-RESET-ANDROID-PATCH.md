# Admin password recovery patch — Android source

## Perubahan yang sudah diterapkan
- Mengganti redirect berbasis `location.origin` pada `file://` dengan deep link khusus `anigamesadmin://recovery`.
- Menerapkan alur yang sama pada halaman Admin utama dan halaman Admin alternatif di folder `icon`.
- Menambahkan Android VIEW/BROWSABLE intent filter untuk menerima link pemulihan.
- Menunda penanganan deep link sampai WebView selesai memuat halaman, sehingga callback tidak hilang karena race condition.
- Memvalidasi token `type=recovery`, membuat sesi Supabase, menampilkan form password baru, lalu memanggil `auth.updateUser`.
- Menghapus ketergantungan Netlify dari alur redirect reset password. Tidak menghapus endpoint atau dokumentasi migrasi yang mungkin masih terkait jalur API lain.

## Konfigurasi Supabase yang tetap diperlukan
Supabase harus mengizinkan redirect URI `anigamesadmin://recovery` pada **Authentication → URL Configuration → Redirect URLs** untuk masing-masing project yang dipakai (DB1 dan DB2). Jika URI belum diizinkan, Supabase dapat menolak redirect atau memakai fallback Site URL; mengganti source APK saja tidak dapat mengubah konfigurasi server.

Email reset harus memakai alur verifikasi resmi Supabase (`{{ .ConfirmationURL }}`), dan link dibuka pada HP yang memasang APK. Setelah konfigurasi siap, uji satu kali dengan akun yang memang terdaftar pada DB aktif: minta email → buka link → masukkan password baru → login ulang.

## Status verifikasi
- Pemeriksaan sintaks JavaScript inline: lulus untuk `admin.html` dan `icon/admin.html`.
- Pemeriksaan statis manifest/deep-link/`updateUser`: lulus.
- APK belum dibuild dan email reset nyata belum diuji end-to-end.
