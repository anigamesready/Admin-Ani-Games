# Admin password recovery patch — Android source

## Perubahan
- Mengganti redirect yang memakai `location.origin` (pada `file://` WebView tidak menunjuk ke halaman HTTPS yang valid) dengan deep link `anigamesadmin://recovery`.
- Menambahkan Android VIEW/BROWSABLE intent filter untuk menerima link pemulihan.
- Meneruskan URI pemulihan ke halaman Admin lokal, memvalidasi token `type=recovery`, membuat sesi Supabase, menampilkan form password baru, lalu memanggil `auth.updateUser`.
- Tidak mengubah alur billing, DB switch, atau UI dashboard selain menambah layar pemulihan.

## WAJIB sebelum uji produksi
1. Tambahkan `anigamesadmin://recovery` ke Supabase Auth > URL Configuration > Redirect URLs pada project DB1 dan DB2 yang digunakan.
2. Email reset harus dibuka pada perangkat yang memasang APK ini; deep link hanya dapat dibuka oleh aplikasi yang terpasang.
3. Supabase email template harus tetap menggunakan link verifikasi/reset Supabase standar (`{{ .ConfirmationURL }}`), bukan menyisipkan token sendiri.
4. Uji satu kali dengan akun uji: minta email, buka link di HP, pastikan form password baru muncul, simpan, lalu login ulang.

## Batas verifikasi
Ini patch sumber, bukan APK. Belum dibuild atau diuji end-to-end karena perlu konfigurasi Redirect URLs pada Supabase dan pengujian email nyata. Link berbasis custom scheme tidak dapat dipastikan bekerja sampai allowlist Supabase diperbarui.

## Patch V3 — database-aware recovery (2026-10-17)
- Recovery access token issuer (`iss`) is decoded to identify the originating Supabase project (DB1 or DB2).
- A dedicated Supabase Auth client is created for that project, so changing the app's selected DB after the email was sent will not route the recovery token to the wrong project.
- `setSession`, `updateUser`, and recovery sign-out use the origin-specific client.
- Both main and alternate Admin HTML pages include the same recovery handling.
- Validation performed: all inline JavaScript blocks in both HTML files pass `node --check`.
- Not yet verified: Android APK build and end-to-end email/token reset. This package must not be treated as a production-tested APK.
