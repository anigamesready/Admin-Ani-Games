# Audit & build status — AniGames Admin V12.1.0

## Baseline protection
- V11 source archive tidak diedit; output dibuat di folder V12.1.0 baru.
- App ID menjadi `com.anigames.billingadmin.v12test` agar build uji tidak menimpa Admin V11.
- `MainActivity` tetap membuka `file:///android_asset/web/admin.html` secara langsung.
- Perubahan PC hanya menambahkan handler command `show_admin_message` di `index.html`; tidak menyentuh `v11-cloud.js`, `renderer.js`, `main.js`, `preload.js`, timer/rental routines, atau pairing.

## Menu Admin yang dipertahankan
Dashboard, PC Aktif, Pairing PC, Laporan, Rental, Branding, StarDesk, Reseller, dan **User Billing Control**. Tambahan V12.1.0: Chat ke Windows dan Database & Sync. Menu User Billing Control diambil kembali dari source basis karena section-nya terhapus pada V12.0.1, walau handler/API-nya masih ada.

## Database selector
- DB1: `wzkjpycjizexxcxrfdvr.supabase.co`.
- DB2: `xcdbipgsvohesxhxydep.supabase.co`.
- Publishable key publik masing-masing project disiapkan dalam source; user tidak lagi diminta memasukkan key manual.
- Memilih target tetap memerlukan login ulang ke Auth project tujuan. Akun/password DB1 tidak otomatis berlaku di DB2.
- Selector hanya memengaruhi aplikasi Admin ini. Belum ada coordinator terverifikasi yang otomatis mengalihkan PC Billing dan aplikasi Reseller secara bersamaan.

## Chat ke Windows
Audit read-only terhadap DB1/DB2 menemukan daftar command yang diizinkan pada `api.admin_command`, `api.queue_command`, serta constraint `device_commands_command_check` belum mengizinkan `show_admin_message`. Body dan constraint kedua project identik. Karena itu disediakan migrasi additive `docs/v12.1.0_enable_admin_chat.sql` untuk dijalankan terpisah di DB1 dan DB2 ketika siap. Migrasi mempertahankan allowlist lama, menambahkan hanya satu command baru, memvalidasi panjang pesan maksimal 240 karakter, serta mempertahankan audit log/security-definer. Migrasi **belum diterapkan ke project aktif**.

PC receiver memanggil modal pesan yang sudah ada dengan teks via `innerText`/text-safe API. Handler tidak menyentuh state timer, rental, pairing, atau power. Chat baru dianggap terkirim saat command berstatus `completed`; timeout ditampilkan sebagai belum terkonfirmasi.

## Database sync
Source audit mengonfirmasi belum ada RPC/Edge Function sinkronisasi lintas-project di kedua DB. UI menyediakan sumber, tujuan, mode update/merge, salin snapshot, overwrite, confirmation prompt dan penjelasan risiko. Eksekusi sengaja tidak dilakukan dan tidak ada tabel/data yang dimodifikasi dari aplikasi, karena backend belum dapat menjamin ID perangkat, sesi rental aktif, command nonterminal, Auth, secrets, Edge Functions dan scheduler disalin dengan benar. Jangan mengaktifkan overwrite lewat klien browser.

## Static checks planned/completed in this bundle
- JS syntax check untuk inline script Admin dan script inline PC.
- Duplicate ID audit pada `admin.html`.
- JSON parse pada Gradle/package/workflow metadata.
- SQL migration reviewed against current `api.admin_command`, `api.queue_command`, and command constraint.

Static checks do not replace build/test. Android APK belum dibangun di runtime ini; belum ada tes login live, pesan sampai PC, tombol/selector fisik, atau E2E pada rental aktif. Deploy migration dan build PC V12 harus dilakukan sebelum menguji chat.
