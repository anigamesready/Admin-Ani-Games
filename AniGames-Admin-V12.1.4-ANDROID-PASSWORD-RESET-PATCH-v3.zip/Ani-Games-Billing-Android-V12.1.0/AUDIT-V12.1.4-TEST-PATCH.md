AniGames Admin V12.1.4 TEST PATCH — AUDIT & LIMITATIONS

Tujuan:
- Memperbaiki layering dan ruang scroll modal pada layar mobile, khususnya agar modal berada di atas navigasi bawah.
- Membuat status DB Admin lebih jelas dan secara eksplisit menandai bahwa status DB aktif global belum terverifikasi.
- Tidak mengaktifkan perpindahan database operasional global dan tidak melakukan sinkronisasi data.

Perubahan:
- CSS modal z-index, batas tinggi berbasis dynamic viewport, overscroll containment, ruang bawah tambahan.
- Label status DB Admin dan label SISTEM GLOBAL: BELUM TERVERIFIKASI.
- Responsifkan kontrol pemilihan DB pada layar kecil.

Yang belum selesai / tidak boleh diasumsikan:
- Belum ada backend global yang mengoordinasikan DB aktif di Admin, PC Billing, dan Reseller.
- Belum ada sinkronisasi/copy DB1↔DB2 yang dieksekusi oleh patch ini.
- Belum ada pemeriksaan kesamaan seluruh tabel utama yang mengizinkan switch produksi.
- PC Billing V11/V12 tidak otomatis berpindah DB hanya dari pilihan di Admin.
- Login Supabase langsung dan tampilan fisik di HP belum diuji dalam runtime nyata.
- ZIP ini adalah source patch untuk pengujian, bukan APK final.

Uji yang dilakukan saat paket dibuat:
- Pemeriksaan struktur ZIP dan file target.
- Pemeriksaan marker UI/CSS patch.
- Tidak mengklaim build Android atau end-to-end test berhasil.
