# Build APK AniGames Admin V12.1.0 (testing)

Paket ini adalah **source project**, belum berisi file APK. Workflow GitHub Actions menghasilkan APK debug terpisah untuk uji V12 dan memakai `applicationId` `com.anigames.billingadmin.v12test`, sehingga tidak menimpa aplikasi Admin V11 yang memakai package lama.

## Langkah build
1. Buat branch/repository pengujian terpisah. Jangan push file ini ke repo produksi/branch `main` milik aplikasi V11.
2. Ekstrak semua isi folder `Ani-Games-Billing-Android-V12.1.0` langsung ke root repo pengujian, termasuk folder `.github`.
3. Push ke branch pengujian atau jalankan **Actions → Build Android APK → Run workflow**.
4. Unduh artifact `Ani-Games-Admin-Android-v12.1.0-debug-apk` setelah job berhasil.

Workflow menggunakan JDK 17, Android SDK 35, Android Gradle Plugin 8.7.3, dan Gradle 8.9. Tidak ada APK yang dihasilkan di sesi audit lokal ini karena SDK/Gradle Android tidak tersedia.

## Isi dan batas fitur
- MainActivity membuka `web/admin.html` langsung; login aplikasi ini diarahkan ke Admin Dashboard, bukan Billing Control.
- UI HP baru mencakup semua menu V12 yang ada, mengembalikan **User Billing Control**, menambah **Chat ke Windows** dan **Database & Sync**.
- Kunci publik Supabase DB1 dan DB2 dibundel di aplikasi; tidak perlu input key manual. Kunci ini public/publishable, bukan service-role secret. Akun Admin tetap harus terdaftar di database yang dipilih.
- Chat membutuhkan receiver PC V12.1.0 dan migrasi `docs/v12.1.0_enable_admin_chat.sql` dijalankan terpisah pada DB1 dan DB2.
- Menu sinkronisasi DB menyiapkan arah serta mode, meminta konfirmasi, tetapi **tidak menulis data** karena backend lintas-project belum tersedia/terverifikasi. Tombol menampilkan alasan dan keluar dengan aman.
- Perpindahan DB berlaku pada aplikasi Admin ini saja. PC Billing dan aplikasi Reseller tidak otomatis ikut pindah.
- Belum ada APK, login live, atau tes hardware/PC yang diklaim selesai; setelah build perlu tes pada salinan V12 sebelum dipakai operasional.
