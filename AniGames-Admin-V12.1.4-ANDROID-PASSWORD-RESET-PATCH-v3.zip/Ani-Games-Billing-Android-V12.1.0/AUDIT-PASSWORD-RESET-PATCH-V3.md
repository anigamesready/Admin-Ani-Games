# AniGames Admin V12.1.4 — Password Reset Patch V3

## Scope
Targeted source patch only. It does not change the locked PC Billing, Android Billing, reseller APK, or Supabase operational data.

## Changes
- Android deep link remains `anigamesadmin://recovery`.
- Recovery JWT issuer is matched to configured DB1/DB2 project URL.
- Recovery session and password update use a dedicated Supabase client for the originating DB, even if the app's current DB selection differs.
- Main and alternate Admin HTML pages updated.

## Checks
- ZIP integrity to be checked after packaging.
- Inline JavaScript syntax checked with Node.js for both Admin pages.
- Android build and real email end-to-end test have not been run. No claim of full success until those tests pass.

## Server settings
Redirect URL must be allowlisted in both Supabase projects. Keep existing URLs until audited; do not remove Netlify from Site URL or allowlist solely based on this patch.
