-- Ani Games Admin V12.1.43: bounded month aggregation for mobile dashboard.
-- The report is scoped to one organization and only aggregates persisted rental sessions.
CREATE OR REPLACE FUNCTION api.report_monthly_rental_summary(
  p_org_id uuid,
  p_from timestamptz,
  p_to timestamptz
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'pg_catalog'
AS $function$
DECLARE
  v_rows jsonb := '[]'::jsonb;
  v_daily jsonb := '[]'::jsonb;
  v_total_sessions bigint := 0;
  v_total_seconds bigint := 0;
  v_rental_count bigint := 0;
  v_from_date date;
  v_to_date date;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'AUTH_REQUIRED';
  END IF;
  IF p_org_id IS NULL OR NOT private.user_has_org_access(p_org_id) THEN
    RAISE EXCEPTION 'ORG_ACCESS_DENIED';
  END IF;
  IF p_from IS NULL OR p_to IS NULL OR p_to <= p_from THEN
    RAISE EXCEPTION 'INVALID_REPORT_RANGE';
  END IF;
  IF p_to - p_from > interval '32 days' THEN
    RAISE EXCEPTION 'MONTH_REPORT_RANGE_TOO_LARGE';
  END IF;

  v_from_date := (p_from AT TIME ZONE 'Asia/Jakarta')::date;
  v_to_date := ((p_to - interval '1 microsecond') AT TIME ZONE 'Asia/Jakarta')::date;

  WITH sessions_in_month AS MATERIALIZED (
    SELECT
      s.id,
      s.rental_account_id,
      COALESCE(r.code, s.code, '-') AS rental_code,
      COALESCE(NULLIF(BTRIM(r.client_label), ''), NULLIF(BTRIM(s.metadata->>'clientLabel'), ''), '-') AS rental_name,
      s.started_at,
      s.ended_at,
      s.deadline_at,
      s.status,
      CASE
        WHEN LOWER(COALESCE(s.status, '')) = 'paused' THEN 0::bigint
        ELSE GREATEST(0, FLOOR(EXTRACT(EPOCH FROM (
          LEAST(COALESCE(s.ended_at, s.deadline_at, NOW()), p_to, NOW())
          - GREATEST(s.started_at, p_from)
        )))::bigint)
      END AS played_seconds
    FROM public.rental_sessions s
    LEFT JOIN public.rental_accounts r ON r.id = s.rental_account_id
    WHERE s.org_id = p_org_id
      AND COALESCE(s.session_type, 'rental') <> 'free_test'
      AND s.started_at < p_to
      AND COALESCE(s.ended_at, s.deadline_at, NOW()) > p_from
  ), grouped AS (
    SELECT
      COALESCE(rental_account_id::text, 'legacy:' || UPPER(rental_code)) AS rental_key,
      MAX(rental_code) AS rental_id,
      MAX(rental_name) AS rental_name,
      SUM(played_seconds)::bigint AS total_play_seconds,
      COUNT(*)::bigint AS total_sessions
    FROM sessions_in_month
    GROUP BY COALESCE(rental_account_id::text, 'legacy:' || UPPER(rental_code))
  )
  SELECT
    COALESCE(JSONB_AGG(JSONB_BUILD_OBJECT(
      'rental_id', rental_id,
      'rental_name', rental_name,
      'total_play_seconds', total_play_seconds,
      'total_sessions', total_sessions
    ) ORDER BY total_play_seconds DESC, rental_id), '[]'::jsonb),
    COALESCE(SUM(total_sessions), 0),
    COALESCE(SUM(total_play_seconds), 0),
    COUNT(*)
  INTO v_rows, v_total_sessions, v_total_seconds, v_rental_count
  FROM grouped;

  WITH days AS (
    SELECT gs::date AS day
    FROM GENERATE_SERIES(v_from_date::timestamp, v_to_date::timestamp, interval '1 day') gs
  ), daily AS (
    SELECT
      d.day,
      COUNT(s.id) FILTER (
        WHERE s.started_at >= (d.day::timestamp AT TIME ZONE 'Asia/Jakarta')
          AND s.started_at < ((d.day + 1)::timestamp AT TIME ZONE 'Asia/Jakarta')
      )::bigint AS sessions_started,
      COALESCE(SUM(
        CASE
          WHEN s.id IS NULL OR LOWER(COALESCE(s.status, '')) = 'paused' THEN 0::bigint
          ELSE GREATEST(0, FLOOR(EXTRACT(EPOCH FROM (
            LEAST(
              COALESCE(s.ended_at, s.deadline_at, NOW()),
              p_to,
              NOW(),
              ((d.day + 1)::timestamp AT TIME ZONE 'Asia/Jakarta')
            )
            - GREATEST(
              s.started_at,
              p_from,
              (d.day::timestamp AT TIME ZONE 'Asia/Jakarta')
            )
          )))::bigint)
        END
      ), 0)::bigint AS active_seconds
    FROM days d
    LEFT JOIN public.rental_sessions s
      ON s.org_id = p_org_id
     AND COALESCE(s.session_type, 'rental') <> 'free_test'
     AND s.started_at < ((d.day + 1)::timestamp AT TIME ZONE 'Asia/Jakarta')
     AND COALESCE(s.ended_at, s.deadline_at, NOW()) > (d.day::timestamp AT TIME ZONE 'Asia/Jakarta')
    GROUP BY d.day
  )
  SELECT COALESCE(JSONB_AGG(JSONB_BUILD_OBJECT(
    'date', day,
    'sessions_started', sessions_started,
    'active_seconds', active_seconds
  ) ORDER BY day), '[]'::jsonb)
  INTO v_daily
  FROM daily;

  RETURN JSONB_BUILD_OBJECT(
    'from', p_from,
    'to', p_to,
    'timezone', 'Asia/Jakarta',
    'rental_count', v_rental_count,
    'total_sessions', v_total_sessions,
    'total_play_seconds', v_total_seconds,
    'rows', v_rows,
    'daily', v_daily
  );
END;
$function$;

REVOKE ALL PRIVILEGES ON FUNCTION api.report_monthly_rental_summary(uuid, timestamptz, timestamptz) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION api.report_monthly_rental_summary(uuid, timestamptz, timestamptz) TO authenticated;
GRANT EXECUTE ON FUNCTION api.report_monthly_rental_summary(uuid, timestamptz, timestamptz) TO service_role;

COMMENT ON FUNCTION api.report_monthly_rental_summary(uuid, timestamptz, timestamptz)
IS 'Organization-scoped monthly summary by rental ID/name with active play seconds and session count, including a daily series for dashboard charts.';
CREATE OR REPLACE FUNCTION api.admin_update_rental_global(
  p_org_id uuid, p_rental_id uuid, p_code text, p_category text,
  p_minutes bigint, p_client_label text, p_expiry_at timestamptz, p_status text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'pg_catalog', 'public'
AS $function$
DECLARE
  uid uuid := auth.uid();
  initial_account_id uuid;
  r public.rental_accounts%ROWTYPE;
  active_session public.rental_sessions%ROWTYPE;
  target_device public.devices%ROWTYPE;
  c text := UPPER(TRIM(COALESCE(p_code, '')));
  cat text := COALESCE(NULLIF(TRIM(p_category), ''), 'reguler');
  st text := COALESCE(p_status, '');
  secs bigint;
  expiry timestamptz := p_expiry_at;
  active_row boolean := false;
  effective_remaining bigint := 0;
  pending_add_seconds bigint := 0;
  added_seconds bigint := 0;
  time_command_id uuid;
  v_lease_until timestamptz;
  v_lease_device_id uuid;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'UNAUTHENTICATED'; END IF;
  IF NOT COALESCE(private.is_owner_access(p_org_id), false)
     AND NOT EXISTS (
       SELECT 1 FROM public.org_members m
       WHERE m.org_id=p_org_id AND m.auth_user_id=uid AND m.role='reseller_admin'
     ) THEN RAISE EXCEPTION 'ADMIN_ORG_ACCESS_DENIED'; END IF;
  IF p_rental_id IS NULL OR c='' OR LENGTH(c)>120 OR c='__TEST10__' THEN
    RAISE EXCEPTION 'RENTAL_FIELDS_INVALID';
  END IF;
  IF p_minutes IS NULL OR p_minutes<0 OR p_minutes>525600 THEN
    RAISE EXCEPTION 'RENTAL_MINUTES_INVALID';
  END IF;
  IF cat NOT IN ('reguler','mingguan','bulanan','hemat','sultan','mega hemat') THEN
    RAISE EXCEPTION 'RENTAL_CATEGORY_INVALID';
  END IF;
  IF st NOT IN ('active','expired','disabled') THEN RAISE EXCEPTION 'RENTAL_STATUS_INVALID'; END IF;

  secs := p_minutes*60;
  IF secs=0 AND st='active' THEN st:='expired'; END IF;

  SELECT id INTO initial_account_id
  FROM public.rental_accounts WHERE id=p_rental_id AND org_id=p_org_id;
  IF initial_account_id IS NULL THEN RAISE EXCEPTION 'RENTAL_NOT_FOUND'; END IF;

  PERFORM pg_advisory_xact_lock(hashtextextended(p_org_id::text||':'||c,0));

  -- Match the timer's lock order: session first, then rental account.
  SELECT * INTO active_session
  FROM public.rental_sessions s
  WHERE s.rental_account_id=p_rental_id AND s.status IN ('active','paused')
  ORDER BY s.started_at DESC,s.id DESC LIMIT 1 FOR UPDATE;
  active_row := FOUND;

  SELECT * INTO r
  FROM public.rental_accounts
  WHERE id=p_rental_id AND org_id=p_org_id
  FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'RENTAL_NOT_FOUND'; END IF;

  IF EXISTS (
    SELECT 1 FROM public.rental_accounts x
    WHERE x.org_id=p_org_id AND UPPER(TRIM(x.code))=c AND x.id<>r.id
  ) THEN RAISE EXCEPTION 'CODE_ALREADY_EXISTS'; END IF;

  IF active_row THEN
    -- PC V12.4.3 add_time safely updates an active countdown. A paused session
    -- must resume first because the legacy paused sync path can reload the old
    -- account balance before the add_time command is applied.
    IF active_session.last_client_at IS NULL THEN RAISE EXCEPTION 'RENTAL_ACTIVE_SESSION_STATE_UNAVAILABLE'; END IF;
    IF c<>UPPER(TRIM(r.code)) THEN RAISE EXCEPTION 'RENTAL_ACTIVE_CODE_LOCKED'; END IF;
    IF expiry IS DISTINCT FROM r.expiry_at THEN RAISE EXCEPTION 'RENTAL_ACTIVE_EXPIRY_LOCKED'; END IF;
    IF st<>'active' THEN RAISE EXCEPTION 'RENTAL_ACTIVE_STATUS_LOCKED'; END IF;

    -- The last PC timer snapshot is the baseline. Include add_time deltas that
    -- are queued, delivered, or completed after that snapshot; this prevents a
    -- second Admin save from issuing the same minutes twice before the next sync.
    SELECT COALESCE(SUM(GREATEST(0,COALESCE((dc.payload->>'seconds')::bigint,0))),0)
      INTO pending_add_seconds
    FROM public.device_commands dc
    WHERE dc.device_id=active_session.device_id
      AND dc.command='add_time'
      AND dc.payload->>'sessionId'=active_session.id::text
      AND (
        dc.status IN ('queued','acknowledged')
        OR (dc.status='completed' AND dc.completed_at>active_session.last_client_at)
      );

    effective_remaining := GREATEST(0,
      COALESCE(active_session.last_client_remaining_seconds,r.remaining_seconds,0)
      - GREATEST(0,FLOOR(EXTRACT(EPOCH FROM (NOW()-active_session.last_client_at)))::bigint)
      + pending_add_seconds
    );

    -- The edit form displays whole minutes. Saving the same displayed minute
    -- is a no-op, not an accidental increase caused by flooring seconds.
    IF p_minutes=FLOOR(r.remaining_seconds/60.0)::bigint THEN
      secs := effective_remaining;
    ELSE
      secs := p_minutes*60;
    END IF;
    IF secs<effective_remaining THEN RAISE EXCEPTION 'RENTAL_ACTIVE_TIME_REDUCTION_BLOCKED'; END IF;

    added_seconds := secs-effective_remaining;
    IF added_seconds>0 THEN
      IF active_session.status='paused' THEN RAISE EXCEPTION 'RENTAL_PAUSED_TIME_EDIT_UNSUPPORTED'; END IF;
      IF active_session.device_id IS NULL THEN RAISE EXCEPTION 'RENTAL_ACTIVE_DEVICE_UNAVAILABLE'; END IF;
      SELECT * INTO target_device
      FROM public.devices d WHERE d.id=active_session.device_id AND d.org_id=p_org_id;
      IF NOT FOUND OR target_device.status<>'online'
         OR COALESCE(target_device.last_heartbeat_at,target_device.last_seen_at) IS NULL
         OR COALESCE(target_device.last_heartbeat_at,target_device.last_seen_at)<NOW()-INTERVAL '45 seconds' THEN
        RAISE EXCEPTION 'RENTAL_ACTIVE_DEVICE_OFFLINE';
      END IF;

      INSERT INTO public.device_commands(org_id,device_id,command,payload,status,created_by)
      VALUES(
        p_org_id,active_session.device_id,'add_time',
        JSONB_BUILD_OBJECT('seconds',added_seconds,'code',r.code,'source','admin-global-active-edit',
          'rentalAccountId',r.id,'sessionId',active_session.id),
        'queued',uid
      ) RETURNING id INTO time_command_id;
    END IF;

    -- Do not write a speculative balance: the PC timer remains authoritative.
    -- It will publish the adjusted remaining time on its next heartbeat.
    UPDATE public.rental_accounts
    SET category=cat,
        client_label=NULLIF(TRIM(p_client_label),''),
        updated_at=NOW(),
        metadata=COALESCE(metadata,'{}'::jsonb)||JSONB_BUILD_OBJECT('source','admin-global-edit','adminEditedAt',NOW())
    WHERE id=r.id;
  ELSE
    IF expiry IS NOT NULL AND expiry<=NOW() THEN RAISE EXCEPTION 'EXPIRY_MUST_BE_FUTURE'; END IF;
    UPDATE public.rental_accounts
    SET code=c,category=cat,remaining_seconds=secs,expiry_at=expiry,
        client_label=NULLIF(TRIM(p_client_label),''),status=st,updated_at=NOW(),
        metadata=COALESCE(metadata,'{}'::jsonb)||JSONB_BUILD_OBJECT('source','admin-global-edit','adminEditedAt',NOW())
    WHERE id=r.id;
  END IF;

  SELECT l.lease_until,l.device_id INTO v_lease_until,v_lease_device_id
  FROM public.rental_offline_leases l WHERE l.rental_account_id=r.id FOR UPDATE;

  INSERT INTO public.audit_logs(org_id,actor_user_id,action,target_type,target_id,payload)
  VALUES(p_org_id,uid,'admin_update_rental_global','rental_account',r.id,
    JSONB_BUILD_OBJECT('old_code',r.code,'new_code',c,
      'old_minutes',FLOOR(r.remaining_seconds/60.0),'new_minutes',p_minutes,
      'old_status',r.status,'new_status',CASE WHEN active_row THEN r.status ELSE st END,
      'active_session',active_row,'seconds_added',added_seconds,'pending_add_seconds',pending_add_seconds,
      'time_command_id',time_command_id,'lease_preserved',v_lease_until>NOW(),
      'lease_until',v_lease_until,'lease_device_id',v_lease_device_id,'device_independent_edit',true));

  RETURN JSONB_BUILD_OBJECT('ok',true,'id',r.id,'org_id',p_org_id,
    'code',CASE WHEN active_row THEN r.code ELSE c END,'category',cat,
    'remaining_seconds',CASE WHEN active_row THEN secs ELSE secs END,
    'expiry_at',CASE WHEN active_row THEN r.expiry_at ELSE expiry END,
    'status',CASE WHEN active_row THEN r.status ELSE st END,'device_id',r.device_id,
    'active_session',active_row,'time_command_queued',time_command_id IS NOT NULL,
    'time_command_id',time_command_id,'seconds_added',added_seconds,'pending_add_seconds',pending_add_seconds,
    'lease_preserved',v_lease_until>NOW(),'lease_until',v_lease_until,'lease_device_id',v_lease_device_id);
END;
$function$;
GRANT EXECUTE ON FUNCTION api.admin_update_rental_global(uuid,uuid,text,text,bigint,text,timestamptz,text) TO authenticated;
GRANT EXECUTE ON FUNCTION api.admin_update_rental_global(uuid,uuid,text,text,bigint,text,timestamptz,text) TO service_role;
